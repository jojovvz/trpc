module.exports = {
	plugins: {
		tailwindcss: {},
	},
};
