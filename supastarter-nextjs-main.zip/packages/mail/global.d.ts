import type { Messages } from "i18n/types";

declare global {
	interface IntlMessages extends Messages {}
}
