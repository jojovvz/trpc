export * from "./generate-product-names";
